<?php
/********************************************************bms_functions.php**************************************************/
	/*
	*	Created By		:	Abhinav Katiyar
	*	Last Modified By   	:	Abhinav Katiyar
	*	Description        	:	This file contains functions for 
						checking availability
	*	Includes/Libraries 	:	./includes/bms_connect.php
/***************************************************************************************************************************/
include_once("./includes/bms_connect.php");

 function checkIfAvail($critarr)
 {
	global $dbbms;

	$zoneid=$critarr["zoneid"];
	$banner=$critarr["bannerid"];
	$priority=$critarr["bannerpriority"];
	$startdt=$critarr["bannerstartdate"];
	$enddt=$critarr["bannerenddate"];
	//echo "here";
	$result=checkAvailability($zoneid,$priority,$critarr,$startdt,$enddt,$banner);
	if($result!="false") $result="true";

	if($result=="false") return 0;
	else return 1;	
	
 }


 function checkAvailability($zoneid,$priority,$critarr,$startdt,$enddt,$banner)
 {
		global $dbbms; 
  		$criterias=$critarr["criteriaarr"];
		$sql="Select ZoneMaxBansInRot from bms2.ZONE where ZoneId='$zoneid'";
		$result=mysql_query($sql,$dbbms) or die(mysql_error($dbbms));
	
		$myrow=mysql_fetch_array($result);
		$maxbansinrot=$myrow["ZoneMaxBansInRot"];
		if($critarr["bannerdefault"]!="Y")
		{	
			for($i=0;$i<count($criterias);$i++)
			{
				if($criterias[$i]=='Location')
	     			{
				        /*$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked' or BannerStatus='ready') and BannerLocation Like '% $str %' and BannerId!='$banner'";
				        echo "<!--$sql-->";
		   			$result=mysql_query( $sql,$dbbms) or die(mysql_error($dbbms));
		   			if($myrow=mysql_fetch_array($result))
		   			{
						if($myrow["cnt"]>=$maxbansinrot)
						{
							return("false");
						}
   	           			}*/

					$country	= $critarr["bannerloc_country"];
					$city		= $critarr["bannerloc_incity"]; 
					$uscity      	= $critarr["bannerloc_uscity"];
					//print_r($country);
					//print_r($city);
					//rint_r($uscity);
					
					$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked' or BannerStatus='ready')";
					
					for($i=0;$i<count($country);$i++)
					{
						if($ctrystr)
						{
							$country[$i] = trim($country[$i]);
							$ctrystr.= " and BannerCountry like '%$country[$i]%'";
							if($country[$i] == 51)
							{
								for($j=0;$j<count($city);$j++)
								{
									$city[$j]= trim($city[$j]);
									{
										if ($incitystr)
										{
											$incitystr.= " and BannerInCity like '%$city[$j]%'";                                                                }
										else
											$incitystr= " and BannerInCity like '%$city[$j]%'";
									}
								}
							
							if($incitystr)
								$ctrystr.= $incitystr;
							}
							if($country[$i] == 127)
							{
								for($j=0;$j<count($uscity);$j++)
								{
									$uscity[$j] = trim($uscity[$j]);
									{
										if ($uscitystr)
										{
											$uscitystr.= " and BannerUsCity like '%$uscity[$j]%'";
										}
										else
											$uscitystr= " and BannerUsCity like '%$uscity[$j]%'";
									}
								}
							
							if($uscitystr)
								$ctrystr.= $uscitystr;
							}
						}
						else
						{       $country[$i] = trim($country[$i]);
							$ctry = trim($country[$i]);
							$ctrystr = " and BannerCountry like '%$country[$i]%'";
							if($country[$i] == 51)
							{	
								for($j=0;$j<count($city);$j++)
								{
										$city[$j] = trim($city[$j]);
										if ($incitystr)
										{	
											$incitystr.= " and BannerInCity like '%$city[$j]%'";                                                                }
										else
										{
											$state=trim($city[$j]);
											if($state!="")
											{	
												$incitystr= " and BannerInCity like '%$state%'";
											}
										}
								}
							
							if($incitystr)
								$ctrystr.= $incitystr;
							}
							if($country[$i] == 127)
							{
								for($j=0;$j<count($uscity);$j++)
								{
									$uscity[$j] = trim($uscity[$j]);
									{
										if ($uscitystr)
										{
											$uscitystr.= " and BannerUsCity like '%$uscity[$j]%'";
										}
										else
											$uscitystr= " and BannerUsCity like '%$uscity[$j]%'";
																	    
									}
								}
							
							if($uscitystr)
								$ctrystr.= $uscitystr;
							}
						}
					}
					$sql.=$ctrystr;
					$sql.= " and BannerId!='$banner'";
					echo "<!--$sql-->";
					$result=mysql_query($sql,$dbbms) or die(mysql_error($dbbms));
					if($myrow=mysql_fetch_array($result))
					{
						
						if($myrow["cnt"]>=$maxbansinrot)
						{
							return("false");
						}
					}

				}
				if($criterias[$i]=='IP')
				{
					$strarr=$critarr["bannerip"];
					//print_r($strarr);	
					for($j=0;$j<count($strarr);$j++)
					{				
						if($strarr[$j] && trim($strarr[$j])!="")
						{
							$locids=getLocids(trim($strarr[$j]));	
							if($locids && trim($locids)!='')
							{
								$locarr=explode(",",$locids);
								for($loc=0;$loc<count($locarr);$loc++)
								{
									$str=trim($locarr[$loc]);
									$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked'  or BannerStatus='ready') and BannerIP Like '% $str %' and BannerId!='$banner'";
									echo "<!--$sql-->";
									$result=mysql_query( $sql,$dbbms) or die(mysql_error($dbbms));
									if($myrow=mysql_fetch_array($result))
									{
										if($myrow["cnt"]>=$maxbansinrot)
										{
											return("false");
										}
									}
								}	
							}
						}
					}
				}
				if($criterias[$i]=='Age')
				{
					$minage=$critarr["banneragemin"];
					$maxage=$critarr["banneragemax"];
					$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked'  or BannerStatus='ready') and ( $maxage >= `BannerAgeMin` AND $minage <= `BannerAgeMax`) and BannerId!='$banner'";
					echo "<!--$sql-->";
					$result=mysql_query( $sql,$dbbms) or die(mysql_error($dbbms));
					if($myrow=mysql_fetch_array($result))
					{
						//echo $myrow["cnt"]."  ";	
						if($myrow["cnt"]>=$maxbansinrot)
						{
							return("false");
						}
					}
				}
				
				if($criterias[$i]=='Ctc')
				{
					if(count($critarr["bannerctc"]) > 0)
						$ctc=implode(",",$critarr["bannerctc"]);
					else
						$ctc=$critarr["bannerctc"];
//					$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked'  or BannerStatus='ready') and ( $maxctc >= `BannerCTCMin` AND $minctc <= `BannerCTCMax`) and BannerId!='$banner'";
 					$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked'  or BannerStatus='ready') and (BannerCTC LIKE '% $ctc %' ) and BannerId!='$banner'";echo "<br>";
		   			$result=mysql_query( $sql,$dbbms) or die(mysql_error($dbbms));
		   			if($myrow=mysql_fetch_array($result))
		   			{
						if($myrow["cnt"]>=$maxbansinrot)
						{
							return("false");
						}
   	           			}
				}
			}
		}
		else 
		{
			$sql="Select count(*) as cnt from bms2.BANNER where ZoneId='$zoneid' and BannerPriority='$priority' and ('$enddt' >= BannerStartDate AND '$startdt' <= BannerEndDate) and (BannerStatus='live' or BannerStatus='booked'  or BannerStatus='ready') and BannerDefault='Y' and BannerId!='$banner'";
			echo "<!--$sql-->";
			$result=mysql_query( $sql,$dbbms) or die(mysql_error($dbbms));
			if($myrow=mysql_fetch_array($result))
			{
				if($myrow["cnt"]>=$maxbansinrot)
				{
					return("false");
				}
			}
		}
 }
?>

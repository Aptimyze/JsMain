<?php
/*********************************************./includes/bms_display_include.php.php****************************************/
  /*
	*	Created By		:	Abhinav Katiyar
	*	Last Modified By   	:	Shobha Kumari
	*	Description	        :	This file includes defines functions for database connection , smarty declar						    -ration , logging of errors.
	*	Includes/Libraries 	:	/usr/local/scripts/bms_config.php
***************************************************************************************************************************/

include_once("/usr/local/scripts/bms_config.php");

$smarty = getSmartyBms();

$bannerclassarr=array("Banner"=>array("Image","Flash"),
		       "Mailer"=>array("MailerFlash","MailerImage"),
		       "PopUp"=>array("PopUp"),
		       "PopUnder"=>array("PopUnder")
				);

/*********************************************************************
	This function is used to take a database connection
	Input : none
	Output : returns value returned by mysql_connect()
/**********************************************************************/
function getConnectionBms()
{
	global $_HOST_NAME , $_USER , $_PASSWORD , $_SITEURL , $dbbms;
        if(!$dbbms = @mysql_connect($_HOST_NAME,$_USER,$_PASSWORD))
	{
		logErrorBms("BMS Site is down for maintenance. Please try after some time.","","ShowErrTemplate");
		defaultbanner();
	}
	@mysql_select_db("bms2",$dbbms);
        return $dbbms;
}

/********************************************************************
	Fetches smarty paths for use at different servers
	Includes the smarty file for use at the 
	input: none
	output: smarty object
********************************************************************/
	  
function getSmartyBms()
{
	global $_SMARTYPATHS,$HTTP_SERVER_VARS,$smarty;
	
	//get smarty path
	$smartypath =$_SMARTYPATHS;

	//include file containing smarty class
	include_once("$smartypath");

	//create a new object for smarty
	if(!isset($smarty))   
		$smarty = new Smarty;
	return $smarty;
}

/*****************************************************************************
	sets the global variable $_LOGPATH to the value of the path of the errorlog of that server.
	input: none
	output: none
*************************************************************************************/
function getLogPathBms()
{
	global $_LOGPATHS,$HTTP_SERVER_VARS,$_LOGPATH,$_SVN,$_ADDLOGPATH;

	//get log path
	$_LOGPATH = $_LOGPATHS.$_SVN.$_ADDLOGPATH;
}

/****************************************************************************************
	logs the error and defines the output to be seen by the user when a sql query dies
	input: message to be logged, query, whether to continue or exit, send a mail or not
	output: error template shown , or exit or coninued with error msg displayed
****************************************************************************************/
function logErrorBms($message,$query="",$critical="exit", $sendmailto="NO")
{
	global $HTTP_REFERER,$HTTP_SERVER_VARS,$HTTP_USER_AGENT, $dbbms, $smarty,$_LOGPATH,$_TPLPATH;

	getLogPathBms();

	ob_start();
 	var_dump($HTTP_SERVER_VARS);
 	$ret_val = ob_get_contents();
 	ob_end_clean();
	$errorstring="echo \"" . date("Y-m-d G:i:s",time() + 37800) . "\nErrorMsg: $message\nMysql Error: " . addslashes(mysql_error()) ."\nMysql Error Number:". mysql_errno()."\nSQL: $query\n#User Agent : $HTTP_USER_AGENT\n #Referer : $HTTP_REFERER \n #Self :  ".$HTTP_SERVER_VARS['PHP_SELF']."\n #Uri : ".$HTTP_SERVER_VARS['REQUEST_URI']."\n #Method : ".$HTTP_SERVER_VARS['REQUEST_METHOD']."\n";
	
	$errorstring.="\" >> $_LOGPATH/bms_disperror".date('dmY').".txt";
	passthru($errorstring);
	$errorstring.="\n#Details : $ret_val";
	
	/* if sendmail option is true then send a mail*/
	if($sendmailto!="NO")
//		$b=mail("abhinav.katiyar@jeevansathi.com","ERROR in bms_connect", $errorstring);

	/* if critical option is set to exit then exit from the script after displaying the error message*/
	if($critical=="exit")
	{
		echo $message;
		exit;
	}
	
	/* if critical option is set to ShowErrTemplate then display error template*/
	elseif($critical=="ShowErrTemplate")
	{
		$smarty->assign("msg_error", $message);
		$smarty->display("./$_TPLPATH/bms_error.htm");
		exit;
	}
	
	/* if critical option is set to continue then display message and continue */
	elseif($critical!="continue")
	{
		echo $message;
	}
}

/***********************************************************************
	This function is used to display a transparent image in case of 
	a mysql error
	input : none
	output : none
***********************************************************************/
function defaultbanner()
{
	global $_SITEURL;
	echo("<img src=$_SITEURL/P/IN/zero.gif>");
}
?>

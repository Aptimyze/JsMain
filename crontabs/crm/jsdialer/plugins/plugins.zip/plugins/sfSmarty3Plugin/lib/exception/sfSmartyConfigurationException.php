<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of sfSmartyConfigurationException
 *
 * @author joshi
 */
class sfSmartyConfigurationException extends Exception
{

}

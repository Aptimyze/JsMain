<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of sfSmartyHelperProxyException
 *
 * @author joshi
 */
class sfSmartyHelperProxyException extends Exception
{
    //put your code here
}

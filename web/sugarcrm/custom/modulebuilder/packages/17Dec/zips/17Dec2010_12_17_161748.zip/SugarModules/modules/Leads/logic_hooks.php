<?php

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1, 'after_save', 'custom/include/Leads/after.php','After', 'After');
?>

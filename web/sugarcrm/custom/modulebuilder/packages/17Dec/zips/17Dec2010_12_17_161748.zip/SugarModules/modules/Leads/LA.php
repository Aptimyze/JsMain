<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
include("/usr/local/scripts/connect_db.php");
include("custom/modules/Leads/config.php");
include("include/utils/Jsde_duplicate.php");
$db=connect_db();

$ignoreList=array();
$duplicateObj=new Duplicate;
if($_REQUEST['std'])
	$std=trim($_REQUEST['std']);
if($_REQUEST['phone_home'])
	$phone_home=trim($_REQUEST['phone_home']);
if($_REQUEST['phone_mobile'])
	$phone_mobile=trim($_REQUEST['phone_mobile']);
if($_REQUEST['enquirer_landline_c'])
	$enquirer_landline_c=trim($_REQUEST['enquirer_landline_c']);
if($_REQUEST['enquirer_mobile_no_c'])
	$enquirer_mobile_no_c=trim($_REQUEST['enquirer_mobile_no_c']);
if($_REQUEST['enquirer_email_id_c'])
	$enquirer_email_id_c=trim($_REQUEST['enquirer_email_id_c']);
if($_REQUEST['lead'])
	$ignoreList[]=trim($_REQUEST['lead']);
if($phone_home || $phone_mobile || $enquirer_landline_c || $enquirer_mobile_no_c || $enquirer_email_id_c)
{
	$duplicate=0;
	if($phone_home)
		$duplicate=$duplicateObj->isDuplicatePhoneInSugar($std.$phone_home,$ignoreList);
	if($enquirer_landline)
		$duplicate=$duplicateObj->isDuplicatePhoneInSugar($std.$enquirer_landline_c,$ignoreList);
	if($phone_mobile)
		$duplicate=$duplicateObj->isDuplicateMobileInSugar($phone_mobile, $ignoreList);
	if($enquirer_mobile)
		$duplicate=$duplicateObj->isDuplicateMobileInSugar($enquirer_mobile,$ignoreList);
	if($enquirer_email_id_c)
		$duplicate=$duplicateObj->isDuplicateEmailInSugar($enquirer_email_id_c,$ignoreList);
	if($duplicate)
	{
		$msg='<font color="red">Duplicate Record!!!</font>';
		echo $msg;
		die;
	}
	die;
}
die;
?>

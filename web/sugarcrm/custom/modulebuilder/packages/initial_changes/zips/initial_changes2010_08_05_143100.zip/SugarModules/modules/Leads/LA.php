<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
include("/usr/local/scripts/connect_db.php");
include("custom/modules/Leads/config.php");
$db=connect_db();

if($_REQUEST['phone_home'])
{
	$field='phone_home';
	$field1='PHONE_RES';
	$field_val=$_REQUEST['phone_home'];
	$field_arr['phone_home']=$_REQUEST['phone_home'];
	$std=$_REQUEST['std'];
}
elseif($_REQUEST['phone_mobile'])
{
	$field='phone_mobile';
	$field1='PHONE_MOB';
	$field_val=$_REQUEST['phone_mobile'];
	$field_arr['phone_mobile']=$_REQUEST['phone_mobile'];
}
if($field_val && $field)
{
	$msg='';
	if($std)
		$sql="SELECT COUNT(*) AS CNT FROM sugarcrm.leads as l, sugarcrm.leads_cstm as lc WHERE l.id=lc.id_c and $field='$field_val' and l.deleted<>1 and lc.std_c='$std'";
	else
		$sql="SELECT COUNT(*) AS CNT FROM sugarcrm.leads WHERE $field='$field_val' and deleted<>1";
	if($_REQUEST['lead'])
		$sql.=" and id<>'".$_REQUEST['lead']."'";
	$res=mysql_query($sql) or die(mysql_error());
	$row=mysql_fetch_assoc($res);
	if($row['CNT'])
	{
		$msg='<font color="red">Duplicate Record!!!</font>';
	}
	elseif($check_js)
	{
		$sql="SELECT  count(*) as CNT from newjs.JPROFILE WHERE $field1='$field_val' and ACTIVATED<>'D'";
		if($std)
			$sql.=" and STD='$std'";
		$res=mysql_query($sql) or die(mysql_error());
		$row=mysql_fetch_assoc($res);
		if($row['CNT'])
			$msg='<font color="red">Duplicate Record!!!</font>';

	}	
	//	$msg='<font color="green">hello!!'.$ph_hm.'</font>';
	$msg=$field.$msg;
	if($msg!='')
 	echo $msg="<msg>".$msg."</msg>";
	die;
}
?>


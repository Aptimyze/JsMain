<?php
 // created: 2010-09-07 16:42:53
$dictionary['Lead']['fields']['lead_source']['default']='1';
$dictionary['Lead']['fields']['lead_source']['audited']=false;
$dictionary['Lead']['fields']['lead_source']['options']='lead_source_list';

 ?>
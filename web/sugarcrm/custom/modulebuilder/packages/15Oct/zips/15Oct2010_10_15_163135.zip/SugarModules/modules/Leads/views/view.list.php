<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.list.php');
//echo '<script type="text/javascript" src="modules/Leads/Ledit1.js" onload=initData();></script>'; 
?>
